$(document).ready(function (){
	
	$('.savebutton_disable').click(function () {
		//to disable save button after single click
        document.getElementById("buttondis").style.display = "none";
    });

	$(".letters_backspace_only").keypress(function (event) {
            	//allows letters, backspace only
            var inputValue = event.which;
            if (window.innerWidth <= 379) {
                if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && (inputValue !== 8) && 			(inputValue !== 0)) {
                    event.preventDefault();
                }
            } else {
                if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && (inputValue !== 8)) {
                    event.preventDefault();
                }
            }
            toUpper(this);
        });
	$(".letters_backspace_whitespace_only").keypress(function (event) {
		//allows letters, backspace, whitespace only 
            var inputValue = event.which;
            if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && (inputValue != 8 && 			inputValue != 32)) {
                event.preventDefault();
            } else {
                toUpper(this);
            }

        });
        


	$(".letters_backspace_numbers_only").keypress(function (event) {
       		//allows letters, backspace, numbers only 
            var inputValue = event.which;
            if (window.innerWidth <= 379) {
                if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 48 && inputValue < 58) && !(inputValue > 96 && 				inputValue < 123) && (inputValue != 8) && (inputValue != 0)) {
                    event.preventDefault();
                } else {
                    toUpper(this);
                }
            } else {
                if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 48 && inputValue < 58) && !(inputValue > 96 && 				inputValue < 123) && (inputValue != 8)) {
                    event.preventDefault();
                } else {
                    toUpper(this);
                }
            }
        });

	$(".letters_backspace_digits_dots_whitespace_only").keypress(function (event) {
		//allows letters,backspace,numbers,whitespace,dots only	
              var inputValue = event.which;
            if (window.innerWidth <= 379) {
                if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 48 && inputValue < 58) && !(inputValue > 96 && 				inputValue < 123) && (inputValue != 8) && (inputValue != 0) && (inputValue != 46) && (inputValue != 32)) {
                    event.preventDefault();
                } else {
                    toUpper(this);
                }
            } else {
                if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 48 && inputValue < 58) && !(inputValue > 96 && 				inputValue < 123) && (inputValue != 8) && (inputValue != 46) && (inputValue != 32)) {
                    event.preventDefault();
                } else {
                    toUpper(this);
                }
            }
        });

	$(".letters_backspace_digits_only").keypress(function (event) {
       		//allows alphabets,backspace,digits only(First letter may or maynot be upper case) 
            var inputValue = event.which;
            if (window.innerWidth <= 379) {
                if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 48 && inputValue < 58) && !(inputValue > 96 && 				inputValue < 123) && (inputValue != 8) && (inputValue != 0)) {
                    event.preventDefault();
                } else {
                    //toUpper(this);
                }
            } else {
                if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 48 && inputValue < 58) && !(inputValue > 96 && 				inputValue < 123) && (inputValue != 8)) {
                    event.preventDefault();
                } else {
                    //toUpper(this);
                }
            }
        });
	
	$(".uppercaseletter_backspace_only").keypress(function (event) {
       		//allows uppercase alphabets and backspace only 
            var inputValue = event.which;
            if (window.innerWidth <= 379) {
                if (!(inputValue > 64 && inputValue < 91) && (inputValue != 8) && (inputValue != 0)) {
                    event.preventDefault();
                } else {
                    toUpper(this);
                }
            } else {
                if (!(inputValue > 64 && inputValue < 91) && (inputValue != 8)) {
                    event.preventDefault();
                } else {
                    toUpper(this);
                }
            }
        });

	var pattern = /\b(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
	x = 46;
	$(".digits_dots_only").keypress(function (e) {
		//allows numbers and dots only (used for ip address validation)
	    if (e.which != 8 && e.which != 0 && e.which != x && (e.which < 48 || e.which > 57)) {
		console.log(e.which);
		return false;
	    }
	}).keyup(function () {
	    var this1 = $(this);
	    if (!pattern.test(this1.val())) {
		$('.message').text('Not Valid IP');
		//displays message as not valid ip
		while (this1.val().indexOf("..") !== -1) {
		    this1.val(this1.val().replace('..', '.'));
		}
		x = 46;
	    } else {
		x = 0;
		var lastChar = this1.val().substr(this1.val().length - 1);
		if (lastChar == '.') {
		    this1.val(this1.val().slice(0, -1));
		}
		var ip = this1.val().split('.');
		if (ip.length == 4) {
		    $('.message').text('Valid IP');
		//displays message as valid ip	
		}
	    }
	});

	$(".digits_backspace_only").keypress(function (event) {
		//allows numbers and backspace only 
            var inputValue = event.which;
		if (!(inputValue > 47 && inputValue < 58) && (inputValue != 8)) {
                event.preventDefault();
            }
        });
        
       
	
	$(".digits_backspace_dots_only").keypress(function (event) {
		//allows numbers,dots and backspace only 
            var inputValue = event.which;            
            if (!(inputValue > 47 && inputValue < 58) && (inputValue != 32 && inputValue != 8 &&  inputValue != 46)) {
                event.preventDefault();
            } else {
                toUpper(this);
            }
        });

	$(".letters_digits_hyphen_comma_dots_colon_whitespace_backspace_cbracket_only").keypress(function (event) {
        var inputValue = event.which;
		//allows alphabets,numbers,hyphen,comma,dots,(,),colon and space only allowed
        if (window.innerWidth <= 379) {
            if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && !(inputValue > 47 && inputValue < 58) && (inputValue !== 8 && inputValue !== 32 && inputValue !== 44 && inputValue !== 45 && inputValue !== 46 && inputValue !== 58 && inputValue !== 40 && inputValue !== 41) && (inputValue !== 0)) {
                event.preventDefault();
            }
        } else {
            if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && !(inputValue > 47 && inputValue < 58) && (inputValue !== 8 && inputValue !== 32 && inputValue !== 44 && inputValue !== 45 && inputValue !== 46 && inputValue !== 58 && inputValue !== 40 && inputValue !== 41)) {
                event.preventDefault();
            }
        }
        toUpper(this);
    });


 $("#parametername").keypress(function (event) {
        var inputValue = event.which;
        // allow letters,backspace,whitespace only
        if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && !(inputValue > 47 && inputValue < 57) && (inputValue != 8 && inputValue != 32)) {
            event.preventDefault();
        } else {
            toUpper(this);
        }

    });
    
    $(".letters_backspace_whitespace_numbers_only").keypress(function (event) {
        //allows letters, backspace,numbers,whitespace only 
        var inputValue = event.which;
//        alert(inputValue);
        if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && !(inputValue > 47 && inputValue < 58) && (inputValue != 8 && inputValue != 32)) {
            event.preventDefault();
        } else {
            toUpper(this);
        }

    });
    
     $(".letters_backspace_cap_only").keypress(function (event) {
       	//allows letters, backspace ,capital only
        var inputValue = event.which;
            if (window.innerWidth <= 379) {
                if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && (inputValue !== 8) && (inputValue !== 0) && !(inputValue > 47 && inputValue < 58)) {
                    event.preventDefault();
                }
            } else {
                if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && (inputValue !== 8) && !(inputValue > 47 && inputValue < 58)) {
                    event.preventDefault();
                }
            }
            tofullUpper(this);
        });
});
        
function toUpper(obj) {
var mystring = obj.value;
//var mystring=trim(mystring);
var sp = mystring.split(' ');
var i, f, r;
var word = new Array();
for (i = 0; i < sp.length; i++) {
  f = sp[i].substring(0, 1).toUpperCase();
  r = sp[i].substring(1).toLowerCase();
  word[i] = f + r;
 }
  var newstring = word.join(' ');
  obj.value = newstring;
  return true;
}

function tofullUpper(obj) {
var mystring = obj.value;
//var mystring=trim(mystring);
var sp = mystring.split(' ');
var i, f, r;
var word = new Array();
for (i = 0; i < sp.length; i++) {
  f = sp[i].substring(0, 1).toUpperCase();
  r = sp[i].substring(1).toUpperCase();
  word[i] = f + r;
 }
  var newstring = word.join(' ');
  obj.value = newstring;
  return true;
}


