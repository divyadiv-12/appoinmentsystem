//Place this script in needed pages
//KeyPress Codes
//a-z ----> 97-122
//A-Z ---->65-90
//backspace ------> 8
//whitespace/spacebar  -----> 32
//Numpad(0-9) -----> 48-57
//Hyphen/Minus ----> 45
//Comma -----> 44
//Full Stop ----> 46
//Colon -----> 58
//Open Parenthesis,( ------> 40
//Closed Parenthesis,) ------->41

$(document).ready(function () {
//    var isMobile = ('ontouchstart' in document.documentElement && navigator.userAgent.match(/Mobi/));
//    if (isMobile == 'Mobi') {
//        alert("Mobile");
//        //only keyup and keydown, keypress is not working in mobile
//    } else {
//        alert("Not Mobile");
//    }
    $(".letters_backspace_only").keypress(function (event) {
//allow letters, backspace only
        var inputValue = event.which;
        if (window.innerWidth <= 379) {
            if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && (inputValue !== 8) && (inputValue !== 0)) {
                event.preventDefault();
            }
        } else {
            if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && (inputValue !== 8)) {
                event.preventDefault();
            }
        }
        toUpper(this);
    });
    $(".letters_backspace_whitespace_only").keypress(function (event) {
        var inputValue = event.which;
        // allow letters,backspace,whitespace only 
        if (window.innerWidth <= 379) {
            if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && (inputValue !== 8 && inputValue !== 32) && (inputValue !== 0)) {
                event.preventDefault();
            }
        } else {
            if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && (inputValue !== 8 && inputValue !== 32)) {
                event.preventDefault();
            }
        }
        toUpper(this);
    });
    $(".letters_backspace_comma_dot_whitespace_only").keypress(function (event) {
        var inputValue = event.which;
        // allow letters,backspace,comma,dot and whitespaces only 
        if (window.innerWidth <= 379) {
            if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && (inputValue !== 32 && inputValue !== 8 && inputValue !== 44 && inputValue !== 46) && (inputValue !== 0)) {
                event.preventDefault();
            }
        } else {
            if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && (inputValue !== 32 && inputValue !== 8 && inputValue !== 44 && inputValue !== 46)) {
                event.preventDefault();
            }
        }
        toUpper(this);
    });
    $(".good_address").keypress(function (event) {
        var inputValue = event.which;
//        Alphabets,digits,Hyphen,Comma,Full Stop,Colon,(,) and space only allowed
        if (window.innerWidth <= 379) {
            if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && !(inputValue > 47 && inputValue < 58) && (inputValue !== 8 && inputValue !== 32 && inputValue !== 44 && inputValue !== 45 && inputValue !== 46 && inputValue !== 58 && inputValue !== 40 && inputValue !== 41) && (inputValue !== 0)) {
                event.preventDefault();
            }
        } else {
            if (!(inputValue > 64 && inputValue < 91) && !(inputValue > 96 && inputValue < 123) && !(inputValue > 47 && inputValue < 58) && (inputValue !== 8 && inputValue !== 32 && inputValue !== 44 && inputValue !== 45 && inputValue !== 46 && inputValue !== 58 && inputValue !== 40 && inputValue !== 41)) {
                event.preventDefault();
            }
        }
        toUpper(this);
    });
    $(".digits_backspace_only").keypress(function (event) {
        var inputValue = event.which;
        // allow digits,backspace only
        if (window.innerWidth <= 379) {
            if (!(inputValue > 47 && inputValue < 58) && (inputValue !== 8) && (inputValue !== 0)) {
                event.preventDefault();
            }
        } else {
            if (!(inputValue > 47 && inputValue < 58) && (inputValue !== 8)) {
                event.preventDefault();
            }
        }
    });
    $('.capAfterDotSpace').on('keypress', function () {
        var val = $(this).val(), regex = /\b[a-z]/g;
        val = val.toLowerCase().replace(regex, function (letter) {
            return letter.toUpperCase();
        });
        this.value = val;
    });
    $('.decimal_data').keypress(function (evt) {
        evt.target.value = evt.target.value
                .replace(/\.(?=.*\.)/g, ''); // Remove all periods unless it is the last one
        if ([8, 46, 37, 39, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 35, 36].indexOf(evt.keyCode || evt.which) === -1)
        {
            evt.returnValue = false;
            if (evt.preventDefault) {
                evt.preventDefault();
            }
        }
    });
    
    $('.validate_email').keyup(function () {
        var emailval = $(this).val();
        var phpat = new RegExp(/^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/);
        var resp = phpat.test(emailval);
        if (resp == false) {
            showMessage('emailErr', 'Enter valid Email Address', $(this).attr('id'));
        } else {
            showMessage('emailSuccess', 'Valid', $(this).attr('id'));
        }
    });
    $('.validate_mob').keyup(function () {
        var mobval = $(this).val();
        var phpat = new RegExp(/^[4-9]{1}[0-9]{9}$/);
        var resp = phpat.test(mobval);
        if (resp == false) {
            showMessage('mobErr', 'Enter valid Mobile Number', $(this).attr('id'));
        } else {
            showMessage('mobSuccess', 'Valid', $(this).attr('id'));
        }
    });
    $('.validate_landph').keyup(function () {
        var landphval = $(this).val();
        var phpat = new RegExp(/^([0-9]{3}[ ]{1}[0-9]{7})$/);
        var resp = phpat.test(landphval);
        if (resp == false) {
            showMessage('landphErr', 'Enter valid Land Phone Number', $(this).attr('id'));
        } else {
            showMessage('landphSuccess', 'Valid', $(this).attr('id'));
        }
    });
    $('.validate_bankacc').keyup(function () {
        var bankacc = $(this).val();
        var phpat = new RegExp(/^[0-9]{6,18}$/);
        var resp = phpat.test(bankacc);
        if (resp == false) {
            showMessage('bankaccErr', 'Enter valid Bank A/c Number', $(this).attr('id'));
        } else {
            showMessage('bankaccSuccess', 'Valid', $(this).attr('id'));
        }
    });
    $('.validate_bifsc').keyup(function () {
        var bifsc = $(this).val();
        var phpat = new RegExp(/^[A-Za-z]{4}[0][A-Za-z0-9]{6}$/);
        var resp = phpat.test(bifsc);
        if (resp == false) {
            showMessage('bifscErr', 'Enter valid IFSC Code', $(this).attr('id'));
        } else {
            showMessage('bifscSuccess', 'Valid', $(this).attr('id'));
        }
    });
});
function toUpper(obj) {
    var mystring = obj.value;
    var sp = mystring.split(' ');
    var i, f, r;
    var word = new Array();
    for (i = 0; i < sp.length; i++) {
        f = sp[i].substring(0, 1).toUpperCase();
        r = sp[i].substring(1).toLowerCase();
        word[i] = f + r;
    }
    var newstring = word.join(' ');
    obj.value = newstring;
    return true;
}

