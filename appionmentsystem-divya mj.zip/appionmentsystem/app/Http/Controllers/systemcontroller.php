<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Validator;
use Exception;
use Response;
use Log;
use Redirect;
use MaddHatter\LaravelFullcalendar\Facades\Calendar;
use Carbon\Carbon;
class systemcontroller extends Controller {

    public function createappoinment() {
        try {
            return view('createappoinment');
        } catch (\Illuminate\Database\QueryException $exception) {
            Log::error($exception->getMessage());
            return redirect('home')->with('value', 'Error Occures Try Again');
        } catch (\Exception $exception) {
            Log::error($exception->getMessage());
            return redirect('home')->with('value', 'Error Occures Try Again');
        }
    }

    public function calender() {
        $events = [];
        $data = DB::table('appoinmentdetails')->get();
        if ($data->count()) {
            foreach ($data as $key => $value) {
                $events[] = Calendar::event(
                                $value->appoinmenttitle, true, new \DateTime($value->appoinmenttime), new \DateTime($value->appoinmenttime . '+1 day'), null,
                                // Add color
                                [
                            'color' => '#df9f9f',
                            'textColor' => '#008000',
                                ]
                );
            }
        }

        $calendar = Calendar::addEvents($events);
        return view('home', compact('calendar'))->with('val', $data);
    }

    public function insertappoinment(Request $request) {
        try {
            $urname = $request->urname;
            $email = $request->email;
            $dob = $request->dob;
            $apptime = date('Y-m-d', strtotime($dob));
            $title = $request->title;
            $data = $request->all();
            $rules = array('urname' => 'required', 'email' => 'required', 'dob' => 'required',
                'title' => 'required'
            );
            $messages = array('urname.required' => 'YourName is Required', 'email.required' => 'Youremail is Required',
                'dob.required' => 'Appoinmenttime is Required',
                'title.required' => 'Appoinmenttitle is Required'
            );
            $validator = Validator::make($data, $rules, $messages);
            if ($validator->fails()) {
                $messages = $validator->messages();
                return redirect()->withErrors($validator)->withInput();
            } else {
                $result = DB::table('appoinmentdetails')->insert(['yourname' => $urname, 'youremail' => $email,
                    'appoinmenttime' => $apptime, 'appoinmenttitle' => $title]);
                return $this->calender();
            }
        } catch (\Illuminate\Database\QueryException $exception) {
            Log::error($exception->getMessage());
            return redirect('home')->with('value', 'Error Occures Try Again');
        } catch (\Exception $exception) {
            Log::error($exception->getMessage());
            return redirect('home')->with('value', 'Error Occures Try Again');
        }
    }

    public function viewdetails(Request $request) {
        $appid = $request->view;
        $sel = DB::table('appoinmentdetails')->select()->where('id', '=', $appid)->get();
        $v = array(array('selectval' => $sel));
//        echo json_encode($v);
        return $this->calender()->with('select',$v);
    }

    public function deleteappoinment(Request $request) {
        try {
            $appid = $request->apid;
            $res = DB::table('appoinmentdetails')->where('id', '=', $appid)->delete();
            return $this->calender();
        } catch (\Illuminate\Database\QueryException $exception) {
            Log::error($exception->getMessage());
            return redirect('home')->with('value', 'Error Occures Try Again');
        } catch (\Exception $exception) {
            Log::error($exception->getMessage());
            return redirect('home')->with('value', 'Error Occures Try Again');
        }
    }

    public function updateappoinment(Request $request) {
        try {
            $appid = $request->apid;
            $urname = $request->urname;
            $email = $request->email;
            $dob = $request->dob;
            $apptime = date('Y-m-d', strtotime($dob));
            $title = $request->title;
            $result1 = DB::table('appoinmentdetails')->where('id', '=', $appid)->update(array('yourname' => $urname,
                'youremail' => $email, 'appoinmenttime' => $apptime, 'appoinmenttitle' => $title));
            return $this->calender();
        } catch (\Illuminate\Database\QueryException $exception) {
            Log::error($exception->getMessage());
            return redirect('home')->with('value', 'Error Occures Try Again');
        } catch (\Exception $exception) {
            Log::error($exception->getMessage());
            return redirect('home')->with('value', 'Error Occures Try Again');
        }
    }

}
