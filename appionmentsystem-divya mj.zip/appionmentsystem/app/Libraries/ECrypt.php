<?php

namespace App\Libraries;
use Illuminate\Support\Facades\Crypt;

class ECrypt {

    function __construct() {
        
    }

    function encrypt($str) {
        return Crypt::encryptString($str);
    }
    
    function decrypt($str) {
        return Crypt::decryptString($str);
    }

}
?>