<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class userreg extends Model
{
    //
}
