<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>@yield('title')</title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <!-- Bootstrap 3.3.7 -->
        <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="{{asset('css/font_awesome.min.css')}}">
        <!-- Ionicons -->
        <link rel="stylesheet" href="{{asset('css/ionicons.min.css')}}">
        <!-- bootstrap slider -->
        <link rel="stylesheet" href="{{asset('css/slider.css')}}">
        <!-- iCheck -->
        <link rel="stylesheet" href="{{asset('iCheck/square/blue.css')}}">
        <!-- AdminLTE Skins. Choose a skin from the css/skins folder instead of downloading all of them to reduce the load. -->
        <link rel="stylesheet" href="{{asset('css/all-skins.min.css')}}">
        <!-- DataTables -->
        <link rel="stylesheet" href="{{asset('css/dataTables.bootstrap.min.css')}}">
        <!-- daterange picker -->
        <link rel="stylesheet" href="{{asset('css/daterangepicker.css')}}">
        <!-- bootstrap datepicker -->
        <link rel="stylesheet" href="{{asset('css/bootstrap-datepicker.min.css')}}">
        <!-- iCheck for checkboxes and radio inputs -->
        <link rel="stylesheet" href="{{asset('iCheck/all.css')}}">
        <!-- Bootstrap Color Picker -->
        <link rel="stylesheet" href="{{asset('css/bootstrap-colorpicker.min.css')}}">
        <!-- Bootstrap time Picker -->
        <link rel="stylesheet" href="{{asset('css/bootstrap-timepicker.min.css')}}">
        <!-- fullCalendar -->
        <link rel="stylesheet" href="{{asset('css/fullcalendar.min.css')}}">
        <!-- Select2 -->
        <link rel="stylesheet" href="{{asset('css/select2.min.css')}}">
        <!-- Theme style -->
        <link rel="stylesheet" href="{{asset('css/AdminLTE.min.css')}}">
        <link rel="stylesheet" href="{{asset('https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic')}}">

        <link rel="stylesheet" href="{{asset('css/myStyle.css')}}">
     <script src="{{ asset('js/validation.js')}}"></script>
        <link rel="stylesheet" href="{{asset('css/imgareaselect.css')}}" />
    </head>
     <!---->
    <body class="hold-transition skin-blue sidebar-mini">      
        <div class="wrapper">
            @include('common.headerMenu')
            @include('common.sideMenu')
            @yield('wrapperContent')
        </div>

        <!--===================Scripts=========================-->
        <!-- jQuery 3.2.1 -->
        <!--<script src="{{ asset('js/jquery.min.js')}}"></script>-->
         <script src="{{ asset('js/select2.full.min.js')}}"></script>

         <!--jQuery UI 1.11.4--> 
        <script src="{{ asset('js/jquery-ui.min.js')}}"></script>
         <!--Bootstrap 3.3.7--> 
        <script src="{{ asset('js/bootstrap.min.js')}}"></script>
         <!--AdminLTE App--> 
        <script src="{{ asset('js/adminlte.min.js') }}"></script>
        
<!--        <script>
         var window_dimensions = "toolbars=no,menubar=no,location=no,scrollbars=yes,resizable=yes,status=yes"
window.opener=self
window.close()
window.open("http://192.168.10.106/ViewStockAndStore/public/viewmainitem","_blank",  window_dimensions);
window.moveTo(0,0);
window.resizeTo(screen.width,screen.height-100);   
        </script>-->
<script>
$(function () {
    $(".sidebar-menu").on('click', 'li', function () {
        $(".sidebar-menu li .active").removeClass("active");
        $(this).addClass("active");
    });
});
        </script>
        <!--iCheck--> 
        <script src="{{ asset('iCheck/icheck.min.js') }}"></script>
        <script>
$(function () {
    //iCheck
    $('input').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        radioClass: 'iradio_square-blue',
        increaseArea: '20%' // optional
    });
    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
        checkboxClass: 'icheckbox_minimal-blue',
        radioClass: 'iradio_minimal-blue'
    });
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
        checkboxClass: 'icheckbox_minimal-red',
        radioClass: 'iradio_minimal-red'
    });
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
        checkboxClass: 'icheckbox_flat-green',
        radioClass: 'iradio_flat-green'
    });
});
        </script>
        <!-- Select2 -->
        <script src="{{ asset('js/select2.min.js')}}"></script>
        
        
        <script>
             $('.testmod').modal({
                    backdrop: 'static',
                });
                </script>
        <script>
$(function () {
//Initialize Select2 Elements
    $('.select2').select2();
});
        </script>
        <!-- fullCalendar -->
        <script src="{{ asset('js/moment.min.js')}}"></script>
        <script src="{{ asset('js/fullcalendar.min.js')}}"></script>
        <!-- InputMask -->
        <script src="{{ asset('js/jquery.inputmask.js')}}"></script>
        <script src="{{ asset('js/jquery.inputmask.date.extensions.js')}}"></script>
        <script src="{{ asset('js/jquery.inputmask.extensions.js')}}"></script>
        <script>
$(function () {
//Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', {'placeholder': 'dd/mm/yyyy'});
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', {'placeholder': 'mm/dd/yyyy'});
    //Money Euro
    $('[data-mask]').inputmask();
});
        </script>
        <!-- date-range-picker -->       
        <script src="{{ asset('js/daterangepicker.js')}}"></script>
        <script>
$(function () {
//Date range picker
    $('.rangepicker').daterangepicker({
        locale: {
            format: 'YYYY-MM-DD'
        }
    });
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
    //Date range as a button
    $('#daterange-btn').daterangepicker(
            {
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                startDate: moment().subtract(29, 'days'),
                endDate: moment()
            },
            function (start, end) {
                $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
            }
    );
});
        </script>
        <!-- bootstrap datepicker -->
        <script src="{{ asset('js/bootstrap-datepicker.min.js')}}"></script>
        <script>
$(function () {
//Date picker
    $('.datepicker').datepicker({
        format: 'dd-mm-yyyy',
        autoclose: true
    });
});
        </script>
        <!-- bootstrap color picker -->
        <script src="{{ asset('js/bootstrap-colorpicker.min.js')}}"></script>
        <script>
$(function () {
//Colorpicker
    $('.my-colorpicker1').colorpicker();
    //color picker with addon
    $('.my-colorpicker2').colorpicker();
});
        </script>
        <!-- bootstrap time picker -->
        <script src="{{ asset('js/bootstrap-timepicker.min.js')}}"></script>
        <script>
$(function () {
//Timepicker
    $('.timepicker').timepicker({
        showInputs: false
    });
});
        </script>

        <!-- DataTables -->
        <script src="{{ asset('js/jquery.dataTables.min.js') }}"></script>
        <script src="{{ asset('js/dataTables.bootstrap.min.js')}}"></script>
        <script>
$(function () {
    $('.datatable1').DataTable({
        'lengthMenu': [15, 30, 60, 120, 240],
// 'order': [[1, 'asc']],
        'rowGroup': [0, 2, 4]
    });
    $('.datatable2').DataTable({
        'paging': true,
        'lengthChange': false,
        'searching': true,
        'ordering': true,
        'info': true,
        'autoWidth': false,
        'scrollY':600
    });
});
        </script>
        
        
        
        <!-- Bootstrap slider -->
        <script src="{{ asset('js/bootstrap-slider.js')}}"></script>
        <script>
$(function () {
    /* BOOTSTRAP SLIDER */
    $('.slider').slider();
});
        </script> 
        <!-- Page script -->
        <script>
            $(function () {
                $('[data-toggle="tooltip"]').tooltip();
                // We can attach the `fileselect` event to all file inputs on the page
                $(document).on('change', ':file', function () {
                    var input = $(this),
                            numFiles = input.get(0).files ? input.get(0).files.length : 1,
                            label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
                    input.trigger('fileselect', [numFiles, label]);
                });
                // We can watch for our custom `fileselect` event like this
                $(document).ready(function () {
                    $(':file').on('fileselect', function (event, numFiles, label) {

                        var input = $(this).parents('.input-group').find(':text'),
                                log = numFiles > 1 ? numFiles + ' files selected' : label;
                        if (input.length) {
                            input.val(log);
                        } else {
                            if (log)
                                alert(log);
                        }

                    });
                });
            });
            function readURL(input, i, y) {
                var d = i - 1;
                if (input.files && input.files[0]) {
                    if (y == 'image') {
                        var src = [];
                        if ((input.files[0].type == 'image/jpeg' || input.files[0].type == 'image/jpg' || input.files[0].type == 'image/png')) {
                            if (input.files[0].size <= 2000000) {
                                for (var f = d; f > 0; f--) {
                                    src.push($('#fip' + f).attr('src'));
                                }
                                var reader = new FileReader();
                                reader.onload = function (e) {
                                    if (src.indexOf(e.target.result) > -1) {
                                       
                                        $("#upic_err" + i).html("<span style='color:red'>Duplication of Image</span>");
                                        $("#imgdiv" + i).empty();
                                        document.getElementById("upic" + i).value = "";
                                        document.getElementById("ftxt" + i).value = "";
                                    } else {
                                       
                                        var isrc = '<img src="' + e.target.result + '" id="fip' + i + '" name="fip' + i + '" alt="" width="" height="" class="img-lg fip" />';
                                        $("#imgdiv" + i).html(isrc);
                                    }

                                };
                                reader.readAsDataURL(input.files[0]);
                            } else {
                                $("#upic_err" + i).html("<span style='color:red'>Image Size exceeds 1 MB</span>");
                                $("#imgdiv" + i).empty();
                                document.getElementById("upic" + i).value = "";
                                document.getElementById("ftxt" + i).value = "";
                            }
                        } else {
                            $("#upic_err" + i).html("<span style='color:red'>Other than png,jpeg,jpg files are not allowed</span>");
                            $("#imgdiv" + i).empty();
                            document.getElementById("upic" + i).value = "";
                            document.getElementById("ftxt" + i).value = "";
                        }
                    } else if (y == 'pdf') {
                        if (input.files[0].type == 'application/pdf') {
                            if (input.files[0].size > 50000000) {
                                $("#upic_err" + i).html("<span style='color:red'>File Size exceeds 50 MB</span>");
                                document.getElementById("upic" + i).value = "";
                                document.getElementById("ftxt" + i).value = "";
                            } else {
                                var arr = [];
                                for (var n = d; n > 0; n--) {
                                    arr.push($('#ftxt' + n).val());
                                }
                                if (arr.indexOf(input.files[0].name) > -1) {
                                    $("#upic_err" + i).html("<span style='color:red'>Duplication of File</span>");
                                    document.getElementById("upic" + i).value = "";
                                    document.getElementById("ftxt" + i).value = "";
                                }
                            }
                        } else {
                            $("#upic_err" + i).html("<span style='color:red'>Other than pdf files are not allowed</span>");
                            document.getElementById("upic" + i).value = "";
                            document.getElementById("ftxt" + i).value = "";
                        }
                    } else if (y == 'both') {
                        if ((input.files[0].type == 'image/jpeg' || input.files[0].type == 'image/jpg' || input.files[0].type == 'image/png')) {
                            var src = [];
                            if (input.files[0].size <= 1000000) {
                                for (var f = d; f > 0; f--) {
                                    src.push($('#fip' + f).attr('src'));
                                }
                                var reader = new FileReader();
                                reader.onload = function (e) {
                                    if (src.indexOf(e.target.result) > -1) {
                                        $("#upic_err" + i).html("<span style='color:red'>Duplication of Image</span>");
                                        $("#imgdiv" + i).empty();
                                        document.getElementById("upic" + i).value = "";
                                        document.getElementById("ftxt" + i).value = "";
                                    } else {
                                        var isrc = '<img src="' + e.target.result + '" id="fip' + i + '" name="fip' + i + '" alt="" width="" height="" class="img-lg fip" />';
                                        $("#imgdiv" + i).html(isrc);
                                    }
                                };
                                reader.readAsDataURL(input.files[0]);
                            } else {
                                $("#upic_err" + i).html("<span style='color:red'>Image Size exceeds 1 MB</span>");
                                document.getElementById("upic" + i).value = "";
                                document.getElementById("ftxt" + i).value = "";
                            }
                        } else if (input.files[0].type == 'application/pdf') {
                            if (input.files[0].size > 50000000) {
                                $("#upic_err" + i).html("<span style='color:red'>File Size exceeds 50 MB</span>");
                                document.getElementById("upic" + i).value = "";
                                document.getElementById("ftxt" + i).value = "";
                            } else {
                                var arr = [];
                                for (var n = d; n > 0; n--) {
                                    arr.push($('#ftxt' + n).val());
                                }
                                if (arr.indexOf(input.files[0].name) > -1) {
                                    $("#upic_err" + i).html("<span style='color:red'>Duplication of File</span>");
                                    document.getElementById("upic" + i).value = "";
                                    document.getElementById("ftxt" + i).value = "";
                                }
                            }
                        } else {
                            $("#upic_err" + i).html("<span style='color:red'>Other than png,jpeg,jpg or pdf files are not allowed</span>");
                            document.getElementById("upic" + i).value = "";
                            document.getElementById("ftxt" + i).value = "";
                        }
                    }
                }
            }
//            function disableBackButton() {
//                window.history.forward()
//            }
//            disableBackButton();
            window.onload = disableBackButton();
            window.onpageshow = function (evt) {
                if (evt.persisted)
                    disableBackButton()
            }
            window.onunload = function () {
                void(0)
            }

            function readURL4singleimg(input, i) {
                if (input.files && input.files[0]) {
                    if ((input.files[0].type == 'image/jpeg' || input.files[0].type == 'image/jpg' || input.files[0].type == 'image/png')) {
                        if (input.files[0].size <= 500000) {
                            var reader = new FileReader();
                            reader.onload = function (e) {
//                    var image = new Image();
//                    image.src = e.target.result;
//                    image.onload = function () {
//                        var height = this.height;
//                        var width = this.width;
//                        if (height > 128 || width > 128) {
//                            $("#upic_err" + i).html("<span style='color:red'>Height and Width must not exceed 128 pixels</span>");
//                            $("#imgdiv" + i).empty();
//                            document.getElementById("upic" + i).value = "";
//                            document.getElementById("ftxt" + i).value = "";
//                        } else {
                                var isrc = '<img src="' + e.target.result + '" id="fip' + i + '" name="fip' + i + '" alt="" width="" height="" class="img-lg fip" />';
                                $("#imgdiv" + i).html(isrc);
//                        }
//                    };
                            };
                            reader.readAsDataURL(input.files[0]);
                        } else {
                            $("#upic_err" + i).html("<span style='color:red'>Image Size exceeds 50 kb</span>");
                            $("#imgdiv" + i).empty();
                            document.getElementById("upic" + i).value = "";
                            document.getElementById("ftxt" + i).value = "";
                        }
                    } else {
                        $("#upic_err" + i).html("<span style='color:red'>Other than png,jpeg,jpg files are not allowed</span>");
                        $("#imgdiv" + i).empty();
                        document.getElementById("upic" + i).value = "";
                        document.getElementById("ftxt" + i).value = "";
                    }
                }
            }
        </script>
    </body>
</html>






