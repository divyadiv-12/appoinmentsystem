<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>AHD</title>
        <style>
            body {
                font-family: "Montserrat", sans-serif;
                /*font-smoothing: antialiased;*/
                background-color: #fac564;
                background-image: url(img/food.png);
                /*https://s3-us-west-2.amazonaws.com/s.cdpn.io/5908/food.png*/
            }

            .container {
                padding: 25px 100px;
                max-width: 1200px;
                margin: 0 auto;
            }

            .document {
                background-color: rgba(250, 197, 100,.5);
                padding: 140px 20px;
                border-radius: 5px;
            }

            h1 {
                text-align: center;
                font-size: 3em;
                margin-bottom: 10px;
                text-transform: uppercase;
                font-weight: bold;
                color: white;
                text-shadow: 0 3px 4px rgba(black,.8);
            }

            .link{
                position: relative;
                padding-left: 500px;

            }

            .link a{
                text-decoration: none;
                color:#fff; 
            }

        </style>
    </head>
    <body>
        <div class="container">
            <div class="document">
                <h1>Sorry, the page you are looking for could not be found.</h1>
                <!--<span class="link"><a href="{{url('logout')}}">Login Again</a></span>-->
            </div>
        </div>
    </body>
</html>


