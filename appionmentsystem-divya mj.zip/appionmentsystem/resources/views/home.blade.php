
@extends('layout.master')
@section('title')
Home | Appoinment System
@endsection
@section('wrapperContent')
<script src="{{asset('js/2.0.2-jquery.min.js')}}"></script>
<script src="{{ asset('js/myScript.js')}}"></script>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.css"/>

<style>
    #navFarm > .nav-tabs > li > a {
        color: #fff;
        border-radius: 0;
    }
    #navFarm > .nav-tabs > li.active > a {
        background-color: #fff;
        color: #444;
    }  
    .tab-title{
        padding-bottom:9px;
        font-size:18px;
        margin:20px 0 20px;
        line-height:1;
        border-bottom:1px solid #eee;
        color:#f94877
    }
    a.disabled{
        pointer-events: none;
    }

    .modal {

        width: 100%; /* Full width */
        height: 100%; /* Full height */
        overflow: auto; /* Enable scroll if needed */

    }

    /* Modal Content/Box */
    .modal-content {
        padding: 20px;
        border: 1px solid #888;
        width: 80%; /* Could be more or less, depending on screen size */
    }

</style>
<script>

$(document).ready(function () {
    $('#create').on('click', function () {
        $.ajax({
            url: "{{URL::asset('createappoinment')}}",
            method: 'get',
            data: {},
            success: function (data) {
                $('#filled').html(data);
            }
        });

    });

    $('#edit').on('click', function () {
        var urname = document.getElementById('urname').value;
        var email = document.getElementById('email').value;
        var dob = document.getElementById('dob').value;
        var title = document.getElementById('title').value;
        var apid =document.getElementById('apid').value;
        var mapForm = document.createElement("form");
                mapForm.method = "post";
                mapForm.action = "{{ URL::asset('updateappoinment')}}";
                var mapInput1 = document.createElement("input");
                mapInput1.type = "hidden";
                mapInput1.name = "_token";
                mapInput1.value = '<?php echo csrf_token() ?>';
                mapForm.appendChild(mapInput1);
                var mapInput = document.createElement("input");
                mapInput.type = "hidden";
                mapInput.name = "urname";
                mapInput.value = urname;
                mapForm.appendChild(mapInput);
                var mapInput2 = document.createElement("input");
                mapInput2.type = "hidden";
                mapInput2.name = "dob";
                mapInput2.value = dob;
                mapForm.appendChild(mapInput2);
                var mapInput3 = document.createElement("input");
                mapInput3.type = "hidden";
                mapInput3.name = "email";
                mapInput3.value = email;
                mapForm.appendChild(mapInput3);
                var mapInput4 = document.createElement("input");
                mapInput4.type = "hidden";
                mapInput4.name = "title";
                mapInput4.value = title;
                mapForm.appendChild(mapInput4);
                var mapInput5 = document.createElement("input");
                mapInput5.type = "hidden";
                mapInput5.name = "apid";
                mapInput5.value = apid;
                mapForm.appendChild(mapInput5);
                document.body.appendChild(mapForm);
                mapForm.submit();
    });
    $('#delete').on('click',function(){
        var c=confirm("Are u sure Want Delete");
        if(c==true){
            var apid =document.getElementById('apid').value;
            var mapForm = document.createElement("form");
                mapForm.method = "post";
                mapForm.action = "{{ URL::asset('deleteappoinment')}}";
                var mapInput1 = document.createElement("input");
                mapInput1.type = "hidden";
                mapInput1.name = "_token";
                mapInput1.value = '<?php echo csrf_token() ?>';
                mapForm.appendChild(mapInput1);
                var mapInput = document.createElement("input");
                mapInput.type = "hidden";
                mapInput.name = "apid";
                mapInput.value = apid;
                mapForm.appendChild(mapInput);
                document.body.appendChild(mapForm);
                mapForm.submit();
        }else{
            return false;
        }
        
        
    });
});


</script>
</script>

<!--modal start-->
<div class="modal fade lg" id="modal-default1" >
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" style="color:red;">Create Appoinment</h4>
            </div>

            <div class="modal-body">

                <div id="filled" class="filled"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
        </div>  
    </div>   
</div>
<div class="modal fade lg" id="modal-default2" >
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" style="color:red;">Appoinment Details</h4>
            </div>

            <div class="modal-body">

                <div id="fill" class="fill"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
        </div>  
    </div>   
</div>
<!--modal end-->
<div class="content-wrapper">
    <section class="content-header">
        <h1>Appoinment System<small>Preview</small></h1>
        <ol class="breadcrumb">
            <li class="active"><a href="#"><i class="glyphicon glyphicon-hand-right"></i> Home</a></li>
        </ol>
    </section>
    <section class="content">        
        <div class="row">
            <div class="col-md-12">
                <!--<div class="box box-widget">-->  
                <!--<div class="box-body">-->
                <?php
                $calendar;
                if (isset($val)) {
                    $v = json_decode($val);
                }
                if (isset($select)) {
                    $s = $select[0]['selectval'];
                }
                ?>
                <div class="col-md-8">
                    <!--<div class="container">-->
                    @if (\Session::has('success'))
                    <div class="alert alert-success">
                        <p>{{ \Session::get('success') }}</p>
                    </div><br />
                    @endif
                    <div class="panel panel-md">
                        <div class="panel-heading">
                            <h2>Appoinment System</h2>
                        </div>

                        <div class="panel-body" >
                            {!! $calendar->calendar() !!}
                            @if(isset($v))
                            @foreach($v as $vv)
                            <form action="{{url('viewdetails')}}" method="post"> 
                                <input type="hidden" name="_token" value="{{ csrf_token() }}"> 
                                <input type="hidden" id=view" name="view" value="{{$vv->id}}"> 
                                <button type="submit"id="save" class="save">{{$vv->appoinmenttitle}}</button>
                                
                            </form>      
                            @endforeach
                            @endif


                        </div>
                    </div>

                    <!--</div>-->
                </div>
                <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.js"></script>
                {!!$calendar->script() !!}
                <!--end-->
                <div class="form-group">
                    <div class="col-md-3">
                        <a data-toggle="modal" data-target="#modal-default1" data-backdrop="static" data-keyboard="false" onclick="savedis1(this);"><button id="create">Create Appoinment</button><a>
                                </div>
                                </div>
                                @if(isset($select))
                                @foreach($s as $ss)
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Your Name&nbsp;<span style="color: red;">*</span></label>
                                    <div class="col-md-3">
                                        <input type="text" id="urname" name="urname" value="{{$ss->yourname}}" class="form-control">
                                        <span class="urname_err" id="urname_err">{{$errors->First('urname')}}</span>
                                    </div>
                                    <!--                </div>
                                                    <div class="form-group">-->
                                    <label class="col-md-3 control-label">Your Email&nbsp;<span style="color: red;">*</span></label>
                                    <div class="col-md-3">
                                        <input type="text" id="email" name="email" value="{{$ss->youremail}}" class="form-control">
                                        <span class="email_err" id="email_err">{{$errors->First('email')}}</span>
                                    </div>
                                </div>
                                </br></br>
                                <div class="form-group">
                                    <label class="col-md-3 control-label">Appoinment Time&nbsp;<span style="color: red;">*</span></label>

                                    <div class="col-md-3">
                                        <input class="form-control" type="text" name="dob" id="dob" value="{{$ss->appoinmenttime}}" class="dob"autocomplete="off"  maxlength="25" onpaste="return false" placeholder="dd-mm-yyyy"oncopy="return false"data-placement="top" data-toggle="tooltip" /><br>
                                    </div>
                                    <span class="dob_err" id="dob_err">{{$errors->First('dob')}}</span>
                                </div>
                                <!--                </div>
                                                <div class="form-group">-->
                                <label class="col-md-3 control-label">Appoinment Title&nbsp;<span style="color: red;">*</span></label>
                                <div class="col-md-3">
                                    <input type="text" id="title" name="title" value="{{$ss->appoinmenttitle}}"class="form-control">
                                </div>
                                <span class="title_err" id="title_err">{{$errors->First('title')}}</span>
                                </br>
                                <input type="hidden" id="apid" name="apid" value="{{$ss->id}}">
                                 
                                    <div class="form-group">
                                        <div class="btn-group">
                                            <button type="button" name="edit" id="edit" class="btn btn-block btn-primary">
                                                <i class="fa fa-save"></i> <strong>Edit</strong>
                                            </button>
                                        </div>
                                        </br></br>
                                        
                                        <div class="btn-group">
                                            <button type="button" name="delete" id="delete" class="btn btn-block  btn-danger">
                                                <i class="fa fa-save"></i> <strong>Delete</strong>
                                            </button>
                                        </div>
                                    </div>
            </div>
                                @endforeach
                                @endif

                                <!--</div>-->


                                <!--</div>-->
                                </div> 
                                </div>

                                </section>
                                </div>
                                <aside class="control-sidebar control-sidebar-dark">
                                    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
                                        <li><a href="#help-tab" data-toggle="tab">Help Note</a></li>
                                        <li><a href="#suggestions-tab" data-toggle="tab">Suggestions</a></li>
                                    </ul>
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="help-tab">
                                            <h3 class="control-sidebar-heading">Home</h3>
                                            <div class="form-group"><label class="control-sidebar-subheading">Fixed layout</label><p>Activate the fixed layout. You can't use fixed and boxed layouts together</p></div>
                                            <div class="form-group"><label class="control-sidebar-subheading">Boxed Layout</label><p>Activate the boxed layout</p></div>
                                            <div class="form-group"><label class="control-sidebar-subheading">Toggle Sidebar</label><p>Toggle the left sidebar's state (open or collapse)</p></div>
                                        </div>
                                        <div class="tab-pane" id="suggestions-tab">
                                            <h3 class="control-sidebar-heading">Home</h3>
                                            <form action="#" method="post">
                                                <div class="form-group">
                                                    <label class="control-sidebar-subheading">Your Email</label>
                                                    <input type="text" name="em" class="form-control" placeholder="youremail@gmail.com" readonly="readonly"/>
                                                </div>
                                                <div class="form-group">
                                                    <label class="control-sidebar-subheading">Your Opinion</label>
                                                    <textarea name="q" class="form-control" placeholder="Search..."></textarea>
                                                </div>
                                                <button type="submit" name="search" id="search-btn" class="btn bg-maroon btn-flat margin">Send</button>
                                            </form>
                                        </div>
                                    </div>
                                </aside>
                                <div class="control-sidebar-bg"></div>
                                @endsection
