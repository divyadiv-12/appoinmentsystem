<header class="main-header">
    <a href="" class="logo">
        <!--<span class="logo-mini"><b>LMD</b></span>-->
        <span class="logo-lg"><b><?php echo e(session('dabbr')); ?></b></span>
     
    </a>
    
    <nav class="navbar navbar-static-top">
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>
        <!--<li> <?php echo e(session('namedetails')); ?>,<?php echo e(session('postdetails')); ?></li>-->
                        <!--<li><a href='#' style="font-size: 12px"><?php echo e(session('rolename')); ?></a></li>-->

        <div class="navbar-custom-menu">  
               <!--<?php echo e(session('namedetails')); ?> Post:<?php echo e(session('postdetails')); ?>--> 
            <ul class="nav navbar-nav">   
            <li><a href='#' style="font-size: 12px"><?php echo e(session('namedetails')); ?></a></li>
                <!--<li><a href='#' style="font-size: 12px"><?php echo e(session('rolename')); ?></a></li>-->
                <li title="Switch App"><a href="<?php echo e(url('switchapp')); ?>" ><i class="glyphicon glyphicon-transfer"></i></a></li>
                <li title="Help">
                    <a href="#" data-toggle="control-sidebar"><i class="glyphicon glyphicon-question-sign"></i></a>
                </li>
<!--                <li class="dropdown user user-menu" title="Profile Updation">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                      <i class="glyphicon glyphicon-user"></i>                        
                    </a>
                    <ul class="dropdown-menu">
                        <li class="user-header">
                            <img src="img/user_icon.jpg" class="img-circle" alt="User Image">
                            <p><?php echo e(session('namedetails')); ?> <small><?php echo e(session('postdetails')); ?></small></p>

                        </li>                  
                        <li class="user-footer">
                            <div class="pull-left">
                                <a href="<?php echo e(url('profileViewByUser')); ?>" class="btn btn-default btn-flat">Profile</a>
                            </div>
                            <div class="pull-right">
                                <a href="<?php echo e(url('usrpassadd')); ?>" class="btn btn-default btn-flat">Change Password</a>
                            </div>
                        </li>
                    </ul>
                </li> -->

                <li title="logout"><a href="<?php echo e(url('logoutinvaliduser')); ?>"><i class="fa fa-power-off"></i></a></li>               
            </ul>
        </div>

    </nav>
</header>