
<script src="<?php echo e(asset('js/2.0.2-jquery.min.js')); ?>"></script>
<script>
$(document).ready(function () {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('#save').on('click', function () {
        var urname = document.getElementById('urname').value;
        var email = document.getElementById('email').value;
        var dob = document.getElementById('dob').value;
        var title = document.getElementById('title').value;
        var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        var em = regex.test(email);
        if ((urname == null) || (urname == "")) {
            alert("Your Name is Mandatory");
        } else if ((email == null) || (email == "")) {
            alert("Your Email is Mandatory");
        } else if (!em) {
            alert("Enter valid Mail");
        } else if ((dob == "") || (dob == null)) {
            alert("appoinment Date is Mandatory");
        } else if ((title == "") || (title == null)) {
            alert('Title is Mandatory');
        } else {
            var today = new Date().getHours();
            if (today >= 9 && today <= 18.30) {
                var mapForm = document.createElement("form");
                mapForm.method = "post";
                mapForm.action = "<?php echo e(URL::asset('insertappoinment')); ?>";
                var mapInput1 = document.createElement("input");
                mapInput1.type = "hidden";
                mapInput1.name = "_token";
                mapInput1.value = '<?php echo csrf_token() ?>';
                mapForm.appendChild(mapInput1);
                var mapInput = document.createElement("input");
                mapInput.type = "hidden";
                mapInput.name = "urname";
                mapInput.value = urname;
                mapForm.appendChild(mapInput);
                var mapInput2 = document.createElement("input");
                mapInput2.type = "hidden";
                mapInput2.name = "dob";
                mapInput2.value = dob;
                mapForm.appendChild(mapInput2);
                var mapInput3 = document.createElement("input");
                mapInput3.type = "hidden";
                mapInput3.name = "email";
                mapInput3.value = email;
                mapForm.appendChild(mapInput3);
                var mapInput4 = document.createElement("input");
                mapInput4.type = "hidden";
                mapInput4.name = "title";
                mapInput4.value = title;
                mapForm.appendChild(mapInput4);
                document.body.appendChild(mapForm);
                mapForm.submit();
            } else {
                alert('#ERROR::Appointment should be created within 9:00 AM to 6:30 PM only');
            } 
        }

    });



});

</script>
<script src="<?php echo e(asset('js/bootstrap-datepicker.min.js')); ?>"></script>
<script>

$('.datepicker').datepicker({
    format: 'dd-mm-yyyy',
    startDate: new Date(),
    autoclose: true,
    daysOfWeekDisabled: [0, 6]
});

</script>

<div class="row">
    <div class="col-md-12">
        <div class="box box-widget">
            <div class="box-body">
                <div class="alert alert-success" style="display:none;">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <?php
                    $fmsg = "Data Saved Successfully";
                    echo $fmsg;
                    ?>
                </div>
                <div class="alert alert-danger" style="display:none;">
                    <button type="button" class="close" data-dismiss="alert">×</button>	
                    <?php
                    $fmsg = "Data  Not Saved";
                    echo $fmsg;
                    ?>
                </div>
                <div class="form-group">
                    <label class="col-md-3 control-label">Your Name&nbsp;<span style="color: red;">*</span></label>
                    <div class="col-md-3">
                        <input type="text" id="urname" name="urname" class="form-control">
                        <span class="urname_err" id="urname_err"><?php echo e($errors->First('urname')); ?></span>
                    </div>
                    <!--                </div>
                                    <div class="form-group">-->
                    <label class="col-md-3 control-label">Your Email&nbsp;<span style="color: red;">*</span></label>
                    <div class="col-md-3">
                        <input type="text" id="email" name="email" class="form-control">
                        <span class="email_err" id="email_err"><?php echo e($errors->First('email')); ?></span>
                    </div>
                </div>
                </br></br>
                <div class="form-group">
                    <label class="col-md-3 control-label">Appoinment Time&nbsp;<span style="color: red;">*</span></label>

                    <div class="col-md-3">
                        <div class="input-group ">
                            <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                            <input class="form-control datepicker" type="text" name="dob" id="dob"  class="dob"autocomplete="off"  maxlength="25" onpaste="return false" placeholder="dd-mm-yyyy"oncopy="return false"  title="Farmer Date of Birth" data-placement="top" data-toggle="tooltip" /><br>
                        </div>
                        <span class="dob_err" id="dob_err"><?php echo e($errors->First('dob')); ?></span>
                    </div>
                    <!--                </div>
                                    <div class="form-group">-->
                    <label class="col-md-3 control-label">Appoinment Title&nbsp;<span style="color: red;">*</span></label>
                    <div class="col-md-3">
                        <input type="text" id="title" name="title" class="form-control">
                    </div>
                    <span class="title_err" id="title_err"><?php echo e($errors->First('title')); ?></span>
                </div>
                </br></br>
                <div class="col-md-12">   
                    <div class="form-group pull-right">
                        <div class="btn-group">
                            <button type="button" name="save" id="save" class="btn btn-block btn-social  btn-primary">
                                <i class="fa fa-save"></i> <strong>Save</strong>
                            </button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>