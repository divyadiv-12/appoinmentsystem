<?php $__env->startSection('title'); ?>
Home | DProject
<?php $__env->stopSection(); ?>
<?php $__env->startSection('wrapperContent'); ?>
<script src="<?php echo e(asset('js/2.0.2-jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/myScript.js')); ?>"></script>
<script>
$(document).ready(function () {
});
</script>
<div class="content-wrapper">
    <section class="content-header">
        <h1>Home<small>Preview</small></h1>
        <ol class="breadcrumb">
            <li class="active"><a href="#"><i class="glyphicon glyphicon-hand-right"></i> Home</a></li>
        </ol>
    </section>
    <section class="content">        
        <div class="row">
            <div class="col-md-12">
                <div class="box box-widget">  
                    <div class="box-body">
                        <form method="post" action="<?php echo e(url('loginact')); ?>" id="register" name="register">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
                            <div class="col-md-12">
                                
                                
                                <div class="form-group">
                                    <label class=" col-md-3 control-label"><span style="color: red;"></span>username</label>
                                <div class="col-md-3">
                                    <input class="form-control" type="text" name="uname" id="uname">
                                </div>
                                </div>
                                <div class="form-group">
                                    <label class=" col-md-3 control-label"><span style="color: red;"></span>password</label>
                                <div class="col-md-3">
                                    <input class="form-control" type="text" name="pswd" id="pswd">
                                </div>
                                </div>
                                <input type="submit" id="login" name="login" value="login"/>
                            </div>
                        </form>
                    </div>
                </div>
            </div> 
        </div>

    </section>
</div>
<aside class="control-sidebar control-sidebar-dark">
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
        <li><a href="#help-tab" data-toggle="tab">Help Note</a></li>
        <li><a href="#suggestions-tab" data-toggle="tab">Suggestions</a></li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane active" id="help-tab">
            <h3 class="control-sidebar-heading">Home</h3>
            <div class="form-group"><label class="control-sidebar-subheading">Fixed layout</label><p>Activate the fixed layout. You can't use fixed and boxed layouts together</p></div>
            <div class="form-group"><label class="control-sidebar-subheading">Boxed Layout</label><p>Activate the boxed layout</p></div>
            <div class="form-group"><label class="control-sidebar-subheading">Toggle Sidebar</label><p>Toggle the left sidebar's state (open or collapse)</p></div>
        </div>
        <div class="tab-pane" id="suggestions-tab">
            <h3 class="control-sidebar-heading">Home</h3>
            <form action="#" method="post">
                <div class="form-group">
                    <label class="control-sidebar-subheading">Your Email</label>
                    <input type="text" name="em" class="form-control" placeholder="youremail@gmail.com" readonly="readonly"/>
                </div>
                <div class="form-group">
                    <label class="control-sidebar-subheading">Your Opinion</label>
                    <textarea name="q" class="form-control" placeholder="Search..."></textarea>
                </div>
                <button type="submit" name="search" id="search-btn" class="btn bg-maroon btn-flat margin">Send</button>
            </form>
        </div>
    </div>
</aside>
<div class="control-sidebar-bg"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>