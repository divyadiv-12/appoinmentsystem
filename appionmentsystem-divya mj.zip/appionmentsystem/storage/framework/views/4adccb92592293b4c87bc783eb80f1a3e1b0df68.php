

<aside class="main-sidebar">
    <section class="sidebar">

        <ul class="sidebar-menu" data-widget="tree" id="innerscroll">
            <!--<div id="testsuji" style="background-color: white">Msg Box</div>-->

            <li>
                <a href="<?php echo e(url('home')); ?>">
                    <i class="fa fa-th"></i>
                    <span>Home</span>
                </a>
            </li>

            
            
                
               

        </ul>
    </section>
    <!-- /.sidebar -->
</aside>