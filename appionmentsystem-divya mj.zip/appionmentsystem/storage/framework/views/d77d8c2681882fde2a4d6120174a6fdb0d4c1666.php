<!--<script src="<?php echo e(asset('js/2.0.2-jquery.min.js')); ?>"></script>

<script>
$(document).ready(function () {
    alert('logintest');
    setInterval(function () {
        var set = $('#testsuji');
        $.ajax({
            url: "<?php echo e(URL::asset('msgset')); ?>",
            type: 'GET',
            data: {calving: 'calving'},
            success: function (data) {
//                        alert(data);
                set.html(data);
            }
        });
    }, 1000 * 60 * 1);
});
</script>-->

<aside class="main-sidebar">
    <section class="sidebar">

        <ul class="sidebar-menu" data-widget="tree" id="innerscroll">
            <!--<div id="testsuji" style="background-color: white">Msg Box</div>-->

            <li>
                <a href="<?php echo e(url('home')); ?>">
                    <i class="fa fa-th"></i>
                    <span>Home</span>
                </a>
            </li>

            
            
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-edit"></i> <span>Register</span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="<?php echo e(url('Register')); ?>"><i class="fa fa-circle-o"></i>Register</a></li>

                    </ul>
                </li>
               

        </ul>
    </section>
    <!-- /.sidebar -->
</aside>